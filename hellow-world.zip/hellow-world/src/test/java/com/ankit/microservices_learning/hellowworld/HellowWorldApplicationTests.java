package com.ankit.microservices_learning.hellowworld;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HellowWorldApplicationTests {

	@Test
	void contextLoads() {
	}

}
